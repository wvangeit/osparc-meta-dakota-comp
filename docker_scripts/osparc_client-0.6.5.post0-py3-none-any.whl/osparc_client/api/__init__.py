from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from osparc_client.api.files_api import FilesApi
from osparc_client.api.meta_api import MetaApi
from osparc_client.api.solvers_api import SolversApi
from osparc_client.api.studies_api import StudiesApi
from osparc_client.api.users_api import UsersApi
from osparc_client.api.wallets_api import WalletsApi
